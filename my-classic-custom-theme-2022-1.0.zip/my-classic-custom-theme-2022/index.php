<!DOCTYPE html>
<html>
<head>
    <title><?php bloginfo('title'); ?></title>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

    <h1><?php bloginfo('title'); ?></h1>
    
    <?php wp_footer(); ?>
</body>
</html>
