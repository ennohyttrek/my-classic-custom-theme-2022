    <nav id="footer-nav" class="footer-nav">
        <?php wp_nav_menu( array( 'theme_location' => 'footer-menu' ) ); ?>
    </nav>
<p>&copy; 2022 Enno Hyttrek</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>